#!/bin/sh

set -eu

/opt/phpdoc/bin/phpdoc
