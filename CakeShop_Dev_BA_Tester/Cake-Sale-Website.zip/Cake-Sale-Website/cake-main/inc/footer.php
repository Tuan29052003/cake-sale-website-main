<!-- Bắt đầu Phần Footer -->
<footer class="footer set-bg" data-setbg="img/footer-bg.jpg">
    <div class="container">
        <div class="row">
            <!-- Cột 1: Giờ làm việc -->
            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="footer__widget">
                    <h6>GIỜ LÀM VIỆC</h6>
                    <ul>
                        <li>Thứ Hai - Thứ Sáu: 08:00 sáng – 08:30 tối</li>
                        <li>Thứ Bảy: 10:00 sáng – 04:30 chiều</li>
                        <li>Chủ Nhật: 10:00 sáng – 04:30 chiều</li>
                    </ul>
                </div>
            </div>

            <!-- Cột 2: Giới thiệu -->
            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="footer__about">
                    <div class="footer__logo">
                        <a href="#"><img src="img/footer-logo.png" alt=""></a>
                    </div>
                    <p>Chúng tôi cung cấp dịch vụ chất lượng cao, đáp ứng mọi nhu cầu của khách hàng với sự tận tâm và chuyên nghiệp.</p>
                    <div class="footer__social">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-instagram"></i></a>
                        <a href="#"><i class="fa fa-youtube-play"></i></a>
                    </div>
                </div>
            </div>

            <!-- Cột 3: Đăng ký nhận tin -->
            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="footer__newslatter">
                    <h6>Đăng ký</h6>
                    <p>Nhận thông tin cập nhật và ưu đãi mới nhất.</p>
                    <form action="#">
                        <input type="text" placeholder="Email">
                        <button type="submit"><i class="fa fa-send-o"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bản quyền -->
    <div class="copyright">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <p class="copyright__text text-white">
                        Bản quyền &copy;<script>document.write(new Date().getFullYear());</script> Tất cả các quyền được bảo lưu | Mẫu này được tạo bởi <i class="fa fa-heart" aria-hidden="true"></i> từ <a href="https://colorlib.com" target="_blank">Colorlib</a>
                    </p>
                </div>
                <div class="col-lg-5">
                    <div class="copyright__widget">
                        <ul>
                            <li><a href="#">Chính sách bảo mật</a></li>
                            <li><a href="#">Điều khoản & Điều kiện</a></li>
                            <li><a href="#">Sơ đồ trang</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Kết thúc Phần Footer -->

<!-- Bắt đầu Tìm kiếm -->
<div class="search-model">
    <div class="h-100 d-flex align-items-center justify-content-center">
        <div class="search-close-switch">+</div>
        <form class="search-model-form">
            <input type="text" id="search-input" placeholder="Tìm kiếm tại đây.....">
        </form>
    </div>
</div>
<!-- Kết thúc Tìm kiếm -->


<!-- Các Plugin Js -->
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.nice-select.min.js"></script>
<script src="js/jquery.barfiller.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/jquery.slicknav.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.nicescroll.min.js"></script>
<script src="js/main.js"></script>
</body>

</html>