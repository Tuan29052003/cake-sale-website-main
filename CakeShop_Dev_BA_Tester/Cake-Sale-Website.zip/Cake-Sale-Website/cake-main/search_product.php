<?php
ob_start();
include($_SERVER['DOCUMENT_ROOT'] . "/cake-main/inc/header.php");
include($_SERVER['DOCUMENT_ROOT'] . "/database/connect.php");

$data = []; // Khởi tạo biến $data

if (isset($_POST['submit']) || isset($_POST['submit1'])) {
    $search = $_POST['search'];
    $query = "SELECT * FROM Products WHERE status = 1 AND is_accept = 1 AND Name LIKE '%$search%' ORDER BY SellPrice DESC";
    $data = mysqli_query($conn, $query);

    if (!$data) {
        echo '<script language="javascript">';
        echo 'alert("Đặt hàng thất bại!!!")';
        echo '</script>';
        header("location: list_product.php");
        exit; // Thêm exit để dừng việc thực thi script
    }
}

$query1 = "SELECT * FROM Category WHERE status = 1";
$Category = mysqli_query($conn, $query1);
?>

<div class="breadcrumb-option">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="breadcrumb__text">
                    <h2>Shop</h2>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="breadcrumb__links">
                    <a href="./index.php">Home</a>
                    <span>Shop</span>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumb End -->

<!-- Shop Section Begin -->
<section class="shop spad">
    <div class="container">
        <div class="shop__option">
            <div class="row">
                <div class="col-lg-7 col-md-7">
                    <div class="shop__option__search">
                        <form action="search_product.php" method="POST">
                            <select name="id_category" id="id_category" onchange="location = this.value;">
                                <option value="">Loại bánh</option>
                                <?php foreach ($Category as $key => $value) { ?>
                                    <option value='list_product_by_category.php?id=<?php echo $value["CategoryId"] ?>'>
                                        <?php echo $value["CategoryName"] ?>
                                    </option>
                                <?php } ?>
                            </select>
                            <input type="text" name="search" class="form-control rounded" placeholder="Search" aria-label="Search" aria-describedby="search-addon" />
                            <button type="submit" name="submit1" class="btn btn-outline-primary">Tìm kiếm</button>
                        </form>
                    </div>
                </div>
                <div class="col-lg-5 col-md-5">
                    <div class="shop__option__right">
                        <select onchange="document.location.href=this.value">
                            <option value="">Price sorting</option>
                            <option value="sort_high_to_low_product.php">High to Low</option>
                            <option value="sort_low_to_high_product.php">Low to High</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <?php if (mysqli_num_rows($data) > 0): ?>
                <?php foreach ($data as $key => $value) : ?>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="product__item">
                            <div class="product__item__pic set-bg">
                                <a href="product_detail.php?id=<?php echo $value['ProductId'] ?> ">
                                    <img src="../admin/uploads/<?php echo $value['Image'] ?>" alt="Chi tiết sản phẩm">
                                </a>
                                <div class="product__label">
                                    <!-- <span>Cupcake</span> -->
                                </div>
                            </div>
                            <div class="product__item__text">
                                <h6>
                                    <a href="product_detail.php?id=<?php echo $value['ProductId']; ?>">
                                        <?php echo $value['Name']; ?>
                                    </a>
                                </h6>
                                <h5>Giá: <?php echo $value['SellPrice'] . ' $USD'; ?></h5>
                                <div>
                                    <?php if ($value['Avaiable_quantity'] > 0): ?>
                                        <button class="btn primary-btn mt-4">
                                            <a style="color: white" href="cart.php?id=<?php echo $value['ProductId']; ?>">Thêm giỏ hàng</a>
                                        </button>
                                    <?php else: ?>
                                        <span style="color: red;">Hết hàng</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12">
                    <p style="color: red;">Không tìm thấy sản phẩm với từ khóa "<?php echo htmlspecialchars($search); ?>".</p>
                </div>
            <?php endif; ?>
        </div>
        <div class="shop__last__option">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="shop__pagination">
                        <a href="#">1</a>
                        <a href="#">2</a>
                        <a href="#">3</a>
                        <a href="#"><span class="arrow_carrot-right"></span></a>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="shop__last__text">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Shop Section End -->

<!-- Map End -->
<?php
include($_SERVER["DOCUMENT_ROOT"] . '/cake-main/inc/footer.php');
?>