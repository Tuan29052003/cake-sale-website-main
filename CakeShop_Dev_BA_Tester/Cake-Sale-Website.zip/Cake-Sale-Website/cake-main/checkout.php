<?php
// Include các tệp cần thiết
ob_start();
include($_SERVER['DOCUMENT_ROOT'] . "/cake-main/inc/header.php");
include($_SERVER['DOCUMENT_ROOT'] . "/database/connect.php");
include($_SERVER['DOCUMENT_ROOT'] . "/cake-main/PHPMailer-master/src/PHPMailer.php");
include($_SERVER['DOCUMENT_ROOT'] . "/cake-main/PHPMailer-master/src/SMTP.php");
include($_SERVER['DOCUMENT_ROOT'] . "/cake-main/PHPMailer-master/src/Exception.php");

function calculateTotal($cart) {
    $total = 0;
    foreach ($cart as $item) {
        $total += $item['sellprice'] * $item['quantity'];
    }
    return $total;
}

function sendOrderEmail($userEmail, $orderDetails) {
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    try {
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->CharSet  = "utf-8";
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'tannhut2111@gmail.com'; // Thay bằng email của bạn
        $mail->Password = 'enfz exit ryic jcrp'; // Thay bằng mật khẩu ứng dụng
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;

        $mail->setFrom('tannhut2111@gmail.com', 'Cake Sale');
        $mail->addAddress($userEmail);
        $mail->isHTML(true);
        $mail->Subject = 'Xác nhận đơn hàng';
        $mail->Body = "<b>Chào bạn!</b><br>Cảm ơn bạn đã đặt hàng.<br>Chi tiết đơn hàng: $orderDetails";

        $mail->send();
    } catch (Exception $e) {
    }
}

function placeOrder($conn, $cart, $user, $address, $numberPhone, $note) {
    $idUser = $user['CustomerId'];
    $currentDate = new DateTime('now', new DateTimeZone('Asia/Ho_Chi_Minh'));
    $dateOrder = $currentDate->format("Y-m-d H:i:s");
    $cartTotals = calculateTotal($cart);

    // Insert order into database
    $sql = "INSERT INTO oders (CustomerId, Note, order_date, address, number_phone, total_price) 
            VALUES ('$idUser', '$note', '$dateOrder', '$address', '$numberPhone', '$cartTotals')";

    $result = mysqli_query($conn, $sql);
    if ($result) {
        $orderId = mysqli_insert_id($conn);

        // Insert order details
        foreach ($cart as $item) {
            $sql = "INSERT INTO orderdetails (Order_Detail_Id, ProductId, Price, Quantity) 
                    VALUES ('$orderId', '{$item['id']}', '{$item['sellprice']}', '{$item['quantity']}')";
            mysqli_query($conn, $sql);

            $updateStock = "UPDATE products SET Avaiable_quantity = Avaiable_quantity - {$item['quantity']} 
                             WHERE ProductId = '{$item['id']}'";
            mysqli_query($conn, $updateStock);
        }

        // Send confirmation email
        $orderDetails = "Tổng tiền: $cartTotals USD";
        sendOrderEmail($user['Email'], $orderDetails);

        // Clear cart
        unset($_SESSION['cart']);

        // Redirect with success message
        echo '<script language="javascript">';
        echo 'alert("Đặt hàng thành công!");';
        echo 'window.location.href = "history_order.php";';
        echo '</script>';
        exit();
    } else {
        echo '<script language="javascript">';
        echo 'alert("Đặt hàng không thành công!!!")';
        echo '</script>';
    }
}

// Main logic
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];
    $cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : []; // Lấy thông tin giỏ hàng
    $cart_totals = calculateTotal($cart); // Tính tổng tiền trước khi sử dụng

    if (isset($_POST['submit'])) {
        $address = $_POST['address'];
        $numberPhone = $_POST['number_phone'];
        $note = $_POST['note'];

        placeOrder($conn, $cart, $user, $address, $numberPhone, $note);
    }
} else {
    echo '<div class="alert alert-danger">';
    echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
    echo '<strong>Vui lòng đăng nhập để mua hàng</strong>';
    echo '<a href="login.php?action=checkout">Đăng nhập</a>';
    echo '</div>';
}
?>

<div class="breadcrumb-option">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="breadcrumb__text">
                    <h2>Thanh Toán</h2>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="breadcrumb__links">
                    <a href="./index.php">Home</a>
                    <a href="./list_product.php">Shop</a>
                </div>
            </div>
        </div>
    </div>
</div>

<section class="shop spad">
    <?php if (isset($_SESSION['user'])) { ?>
        <div class="container">
            <div class="shop__option">
                <div class="row">
                    <div class="col-lg-5 col-md-5">
                        <form method="post">
                            <div class="form-group">
                                <label for="full_name">Họ và tên</label>
                                <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo $user['Fullname'] ?>" required placeholder="Nguyễn Văn A"  pattern="^[a-zA-ZÀ-ỹ\s]{2,}$" >
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo $user['Email'] ?>" required placeholder="nguyenvana@gmail.com">
                            </div>
                            <div class="form-group">
                                <label for="address">Địa chỉ</label>
                                <input type="text" class="form-control" id="address" name="address" required placeholder="quận x, TP.HCM">
                            </div>
                            <div class="form-group">
                                <label for="number_phone">Số điện thoại</label>
                                <input type="tel" class="form-control" id="number_phone" name="number_phone" required placeholder="0123456789" minlength="10" maxlength="11" pattern="\d{9,10}">
                            </div>
                            <div class="form-group">
                                <label for="note">Ghi chú</label>
                                <textarea type="text" class="form-control" id="note" name="note" placeholder="Hàng dễ vỡ xin nhẹ tay !!!"></textarea>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-success" name="submit">Thanh toán</button>
                            </div>
                        </form>
                    </div>
                    <div class="col-lg-1 col-md-1"></div>
                    <div class="col-lg-6 col-md-6">
                        <div class="table-responsive text-nowrap">
                            <h4>Thông tin chi tiết đơn hàng</h4>
                            <table class="table" style="text-align: center">
                                <thead>
                                    <tr>
                                        <th>STT</th>
                                        <th>Tên sản phẩm</th>
                                        <th>Số lượng</th>
                                        <th>Đơn giá</th>
                                    </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                                    <?php
                                    $stt = 1;
                                    foreach ($cart as $key => $value) : ?>
                                        <tr>
                                            <td><?php echo $stt++ ?></td>
                                            <td><?php echo $value['name'] ?></td>
                                            <td><?php echo $value['quantity'] ?></td>
                                            <td><?php echo $value['sellprice'] ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <tr>
                                        <td>Tổng tiền</td>
                                        <td colspan="6" class="text-center bg-infor"><?php echo number_format($cart_totals) ?> USD</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
</section>

<?php include($_SERVER['DOCUMENT_ROOT'] . "/cake-main/inc/footer.php"); ?>
