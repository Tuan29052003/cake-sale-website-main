<?php
    $conn = mysqli_connect('localhost','root','','banhang_php');
    mysqli_set_charset($conn,'utf8');
?>