<?php
include($_SERVER['DOCUMENT_ROOT'] . "/database/connect.php");

function deleteProduct($conn) {
    // Kiểm tra nếu có 'id' trong URL
    if (!isset($_GET['id'])) {
        return "Không có ID sản phẩm để xóa.";
    }

    $id = $_GET['id'];

    $query = "DELETE FROM Products WHERE ProductId = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        return "Xóa sản phẩm thành công!";
    }
}

$message = deleteProduct($conn);

if (!empty($message)) {
    echo "<script>alert('$message'); window.location.href = 'product_list.php';</script>";
}
?>
