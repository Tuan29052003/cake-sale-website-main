<?php
include($_SERVER['DOCUMENT_ROOT'] . "/admin/inc/header.php");
include($_SERVER['DOCUMENT_ROOT'] . "/admin/inc/navbar.php");
include($_SERVER['DOCUMENT_ROOT'] . "/database/connect.php");
include($_SERVER['DOCUMENT_ROOT'] . "/admin/html/order_model.php");

$orderModel = new OrderModel($conn); // Tạo đối tượng OrderModel

// Xử lý phân trang
$limit = 5;
$totalQuery = "SELECT COUNT(*) as total FROM oders";
$totalResult = mysqli_query($conn, $totalQuery);
$totalData = mysqli_fetch_assoc($totalResult);
$total = $totalData['total'];
$page = ceil($total / $limit);
$cr_page = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 1;
$start = ($cr_page - 1) * $limit;

// Lấy danh sách đơn hàng
$orders = $orderModel->getAllOrders($limit, $start);
?>

<div class="layout-page">
  <nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme" id="layout-navbar">
    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
      <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
        <i class="bx bx-menu bx-sm"></i>
      </a>
    </div>
  </nav>

  <div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
      <h4 class="fw-bold py-3 mb-4">Danh sách đơn đặt hàng</h4>
      
      <div class="card">
        <div class="table-responsive text-nowrap">
          <table class="table" style="text-align: center">
            <thead>
              <tr>
                <th>STT</th>
                <th>Tên khách hàng</th>
                <th>Tổng tiền</th>
                <th>Ngày đặt</th>
                <th>Trạng thái</th>
                <th>Chức năng</th>
              </tr>
            </thead>
            <tbody class="table-border-bottom-0">
              <?php foreach ($orders as $key => $value): ?>
                <tr>
                  <td><?php echo $key + 1 ?></td>
                  <td><?php echo $value['Fullname'] ?></td>
                  <td><?php echo $value['total_price'] ?></td>
                  <td><?php echo $value['order_date'] ?></td>
                  <td>
                    <?php 
                      if ($value['status'] == 0) { echo "<span class='label bg-red'>Chưa xử lý</span>"; }
                      elseif ($value['status'] == 1) { echo "<span class='label bg-yellow'>Đang xử lý</span>"; }
                      elseif ($value['status'] == 2) { echo "<span class='label bg-blue'>Đã xử lý</span>"; }
                      elseif ($value['status'] == 3) { echo "<span class='label bg-green'>Đã giao hàng</span>"; }
                    ?>
                  </td>
                  <td>
                    <a href="order_detail.php?id=<?php echo $value['OderId'] ?>" class="btn btn-primary">Chi tiết</a>
                    <a href="order_delete.php?id=<?php echo $value['OderId'] ?>" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn xóa ?')">Xóa</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

      <?php if ($page > 1) { ?>
        <hr>
        <nav aria-label="Page navigation">
          <ul class="pagination">
            <?php
            if ($cr_page - 1 > 0) {
              echo "<li class='page-item'><a class='page-link' href='order_list.php?page=1'><i class='bx bx-chevrons-left'></i></a></li>";
              echo "<li class='page-item'><a class='page-link' href='order_list.php?page=".($cr_page - 1)."'><i class='bx bx-chevron-left'></i></a></li>";
            }

            for ($i = 1; $i <= $page; $i++) {
              $active = ($cr_page == $i) ? 'active' : '';
              echo "<li class='page-item $active'><a class='page-link' href='order_list.php?page=$i'>$i</a></li>";
            }

            if ($cr_page + 1 <= $page) {
              echo "<li class='page-item'><a class='page-link' href='order_list.php?page=".($cr_page + 1)."'><i class='bx bx-chevron-right'></i></a></li>";
              echo "<li class='page-item'><a class='page-link' href='order_list.php?page=$page'><i class='bx bx-chevrons-right'></i></a></li>";
            }
            ?>
          </ul>
        </nav>
      <?php } ?>
    </div>
  </div>
</div>

<?php include($_SERVER["DOCUMENT_ROOT"] . '/admin/inc/footer.php'); ?>


